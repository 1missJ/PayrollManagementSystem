<?php
session_start();

// Redirect if the admin is not logged in
if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "payrollsystem";

$conn = new mysqli($servername, $username, $password, $database);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch employee salary slip details (if employee_id is passed via GET)
$employeeData = null;
$deductionsData = [];
$payrollId = null;

if (isset($_GET['employee_id'])) {
    $employeeId = $_GET['employee_id'];

    // Check if payroll record already exists for the employee
    $payrollQuery = "
        SELECT id FROM payroll 
        WHERE employee_id = ? 
        LIMIT 1
    ";
    $stmt = $conn->prepare($payrollQuery);
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $payrollResult = $stmt->get_result();

    // If payroll record does not exist, create a new one
    if ($payrollResult->num_rows === 0) {
        $insertPayrollQuery = "
            INSERT INTO payroll (employee_id, date_from, date_to)
            VALUES (?, NOW(), NOW() + INTERVAL 1 MONTH)
        ";
        $stmt = $conn->prepare($insertPayrollQuery);
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();

        // Retrieve the generated payroll ID
        $payrollId = $conn->insert_id;
    } else {
        // Get the existing payroll ID if it exists
        $payrollId = $payrollResult->fetch_assoc()['id'];
    }

    // Fetch salary details
    $salaryDetailsQuery = "
        SELECT 
            e.id, 
            CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
            e.contact_num, 
            e.position, 
            e.monthly_salary, 
            (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_salary, 
            e.email, 
            b.branch_name, 
            b.department_manager, 
            b.department_address,
            COALESCE(SUM(d.amount), 0) AS total_deductions,
            p.id AS payroll_id,
            p.date_from,
            p.date_to
        FROM employees e
        LEFT JOIN branch_employee be ON e.id = be.employee_id
        LEFT JOIN branch b ON be.branch_id = b.id
        LEFT JOIN deduction d ON e.id = d.employee_id
        LEFT JOIN payroll p ON e.id = p.employee_id
        WHERE e.id = ? AND p.id = ? AND d.status != 'disabled' -- Filter disabled employees
        GROUP BY e.id, p.id
    ";

    $stmt = $conn->prepare($salaryDetailsQuery);
    $stmt->bind_param("ii", $employeeId, $payrollId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $employeeData = $result->fetch_assoc();
    }

    // Fetch all deductions for the employee
    $deductionsQuery = "
        SELECT d.deduction_name, d.amount
        FROM deduction d
        WHERE d.employee_id = ?
    ";
    $stmt = $conn->prepare($deductionsQuery);
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $deductionsResult = $stmt->get_result();

    while ($row = $deductionsResult->fetch_assoc()) {
        $deductionsData[] = $row;
    }
}

// Handle disabling an employee
if (isset($_POST['disable_employee_id'])) {
    $disableEmployeeId = $_POST['disable_employee_id'];

    // Update the status of the employee in the deductions table to 'disabled'
    $updateStatusQuery = "
        UPDATE deduction 
        SET status = 'disabled' 
        WHERE employee_id = ?
    ";
    $stmt = $conn->prepare($updateStatusQuery);
    $stmt->bind_param("i", $disableEmployeeId);
    $stmt->execute();

    // Redirect back to the salary slip page
    header("Location: salarySlip.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Slip</title>
    <link rel="stylesheet" href="./assets/css/salarySlip.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>

    <style>
        /* Modal background */
.salary-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1000;
}

/* Modal content box */
.salary-modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 30px;
    border-radius: 8px;
    width: 80%;
    max-width: 600px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    font-family: Arial, sans-serif;
}

/* Salary slip header */
.salary-header p {
    font-size: 16px;
    margin: 5px 0;
}

/* Earnings and deductions sections */
h3 {
    font-size: 18px;
    margin-top: 20px;
    font-weight: bold;
}

.earnings, .deductions {
    margin-top: 10px;
}

.earnings-details, .deductions-details {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
}

.earning-item, .deduction-item {
    width: 45%;
    font-size: 16px;
}

.net-pay {
    margin-top: 20px;
    font-size: 16px;
    font-weight: bold;
}

/* Modal buttons */
.modal-buttons {
    margin-top: 30px;
    display: flex;
    justify-content: space-between;
}

.modal-buttons button {
    padding: 12px 25px;
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    width: 48%;
}

.modal-buttons .close-btn {
    background-color: #f44336;
}

.modal-buttons .send-btn {
    background-color: #008CBA;
}

.modal-buttons button:hover {
    background-color: #45a049;
}
        /* Base styles for the link */
        .view {
            display: inline-block;
            padding: 10px 20px;
            background-color:rgb(234, 163, 101); /* Bootstrap's primary blue color */
            color: white;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            margin-left: 65px;
        }
        
        /* Hover effect */
        .view:hover {
            background-color:rgb(134, 93, 58); /* Darker blue on hover */
        }

    </style>
</head>
<body>
    <!-- Header -->
    <?php include_once("./includes/header.php"); ?>

    <!-- Sidebar -->
    <?php include_once("./includes/sidebar.php"); ?>

    <main class="content">
        <div class="salary-box">Salary Slip</div>
        <div class="controls">
            <div class="search-container">
                <input type="text" placeholder="Search" class="search-bar">
                <button class="search-btn">🔍</button>
            </div>
        </div>
        <table class="form-container">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Monthly Salary</th>
                    <th>Total Deductions</th>
                    <th>Net Salary</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $salaryDetailsQuery = "
                        SELECT 
                            e.id, 
                            CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
                            e.monthly_salary, 
                            (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_salary, 
                            COALESCE(SUM(d.amount), 0) AS total_deductions
                        FROM employees e
                        LEFT JOIN deduction d ON e.id = d.employee_id
                        WHERE d.status != 'disabled'  -- Exclude disabled employees
                        GROUP BY e.id
                    ";
                    $result = $conn->query($salaryDetailsQuery);

                    if ($result->num_rows > 0):
                        while ($row = $result->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['employee_name']) ?></td>
                        <td>₱<?= number_format($row['monthly_salary'], 2) ?></td>
                        <td>₱<?= number_format($row['total_deductions'], 2) ?></td>
                        <td>₱<?= number_format($row['net_salary'], 2) ?></td>
                        <td>
                            <a href="salarySlip.php?employee_id=<?= $row['id'] ?>" class="view">
                                <img src='./assets/images/eye.png' alt='view' style='height: 20px; width: 20px; padding-top: 5px'>
                            </a>
                            <form action="salarySlip.php" method="post" style="display:inline;">
                                <input type="hidden" name="disable_employee_id" value="<?= $row['id'] ?>">
                               
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No salary data found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>

    <!-- Salary Slip Modal -->
    <?php if ($employeeData): ?>
    <div id="salary-modal" class="salary-modal">
        <div class="salary-modal-content" id="salary-slip-content">
        <h2 style="text-align: center;">Salary Slip for <?= date('F Y') ?></h2>
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <tr>
                    <td colspan="2" style="text-align: left; padding: 8px;">
                        <p><strong>Employee ID:</strong> <?= htmlspecialchars($employeeData['id']) ?></p>
                    </td>
                    <td colspan="2" style="text-align: left; padding: 8px;">
                        <p><strong>Employee Name:</strong> <?= htmlspecialchars($employeeData['employee_name']) ?></p>
                    </td>
                </tr>
            </table>

            <table style="width: 100%; border: 1px solid #000; border-collapse: collapse; margin-top: 10px;">
                <tr>
                    <th style="border: 1px solid #000; padding: 8px;">Earnings</th>
                    <th style="border: 1px solid #000; padding: 8px;">Amount</th>
                    <th style="border: 1px solid #000; padding: 8px;">Deduction</th>
                    <th style="border: 1px solid #000; padding: 8px;">Amount</th>
                </tr>
                <tr>
                    <td style="border: 1px solid #000; padding: 8px;">Base Salary</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right;">
                        ₱<?= number_format($employeeData['monthly_salary'], 2) ?>
                    </td>
                    <td style="border: 1px solid #000; padding: 8px;">
                        <?php if (count($deductionsData) > 0): ?>
                            <?php foreach ($deductionsData as $index => $deduction): ?>
                                <p><?= htmlspecialchars($deduction['deduction_name']) ?></p>
                                <?php if ($index < count($deductionsData) - 1): ?><br><?php endif; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>-</p>
                        <?php endif; ?>
                    </td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right;">
                        <?php if (count($deductionsData) > 0): ?>
                            <?php foreach ($deductionsData as $deduction): ?>
                                <p>₱<?= number_format($deduction['amount'], 2) ?></p>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>-</p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td style="border: 1px solid #000; padding: 8px;"><strong>Total Earnings:</strong></td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right;">
                        ₱<?= number_format($employeeData['monthly_salary'], 2) ?>
                    </td>
                    <td style="border: 1px solid #000; padding: 8px;"><strong>Total Deductions:</strong></td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right;">
                        ₱<?= number_format($employeeData['total_deductions'], 2) ?>
                    </td>
                </tr>
            </table>
            <div style="margin-top: 20px; font-size: 18px; font-weight: bold; text-align: right;">
                <p>Net Pay: ₱<?= number_format($employeeData['net_salary'], 2) ?></p>
            </div>

            <div class="modal-buttons">
                <button class="close-btn" onclick="closeModal()">Close</button>
                <button class="send-btn" onclick="saveAsImage()">Save</button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php include_once("./modal/logout-modal.php"); ?>
    <script>
        // Ensure the modal opens automatically if the page is loaded with an employee ID
        window.onload = function() {
            <?php if ($employeeData): ?>
                document.getElementById('salary-modal').style.display = 'block';
            <?php endif; ?>
        };

        // Close the modal
        function closeModal() {
            document.getElementById('salary-modal').style.display = 'none';
        }

        // Function to save the salary slip as an image
        function saveAsImage() {
    var salarySlipContent = document.getElementById('salary-slip-content');
    var modalButtons = document.querySelector('.modal-buttons');

    // Temporarily hide buttons
    modalButtons.style.display = 'none';

    html2canvas(salarySlipContent, {
        scale: 3, // Higher scale for better resolution
        useCORS: true,
        onclone: (documentClone) => {
            // Ensure CSS is applied within the cloned DOM
            var originalStyles = document.querySelectorAll('style, link[rel="stylesheet"]');
            originalStyles.forEach(style => {
                documentClone.head.appendChild(style.cloneNode(true));
            });
        }
    }).then(function (canvas) {
        // Convert canvas to image
        var link = document.createElement('a');
        link.href = canvas.toDataURL('image/png');
        link.download = `Salary_Slip_${new Date().toISOString().slice(0, 10)}.png`;

        // Trigger download
        link.click();

        // Restore buttons after download
        modalButtons.style.display = 'flex';
    }).catch(function (error) {
        console.error('Error capturing salary slip:', error);
    });
}

    </script>

</body>
</html>

<style>
    .footer {
        position: fixed;
        bottom: 0;
        width: 100%;
        text-align: center;
        padding: 10px;
        background-color: #fff3e0;
        font-size: 0.9rem;
        color: #333;
        border-top: 1px solid #ccc;
        }
</style>
<footer class="footer">
        © 2024 Payroll Management System. All rights reserved.
</footer>
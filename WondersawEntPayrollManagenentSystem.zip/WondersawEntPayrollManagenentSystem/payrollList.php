<?php 
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Connect to the database
include_once("connection.php");

// Default to current month and year if not set
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Handle deleting a payroll record
if (isset($_GET['delete_id'])) {
    $payrollId = $_GET['delete_id'];

    // Delete the payroll record from the database
    $stmt = $conn->prepare("DELETE FROM payroll WHERE id = ?");
    $stmt->bind_param("i", $payrollId);

    if ($stmt->execute()) {
        echo "<script>alert('Payroll record deleted successfully'); window.location.href='payrollList.php';</script>";
    } else {
        echo "<script>alert('Error deleting payroll record');</script>";
    }
}

// Query to fetch payroll data with net_pay calculation
$sql = "
    SELECT p.id, p.date_from, p.date_to, 
           CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
           e.position,
           (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_pay
    FROM payroll p
    LEFT JOIN employees e ON e.id = p.employee_id
    LEFT JOIN deduction d ON d.employee_id = e.id
    WHERE MONTH(p.date_from) = ? AND YEAR(p.date_from) = ?
    GROUP BY p.id, e.id, e.monthly_salary
    ORDER BY p.date_from DESC
";


$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $month, $year);
$stmt->execute();
$result = $stmt->get_result();

// Fetch all employees for the dropdown
$searchTerm = isset($_POST['search']) ? $_POST['search'] : '';  // Search term
$searchSql = "SELECT id, first_name, last_name FROM employees WHERE CONCAT(first_name, ' ', last_name) LIKE ?";
$searchStmt = $conn->prepare($searchSql);
$searchTerm = '%' . $searchTerm . '%';
$searchStmt->bind_param("s", $searchTerm);
$searchStmt->execute();
$employeesResult = $searchStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll List</title>
    <link rel="stylesheet" href="./assets/css/payrollList.css">
    <style>
        /* Modal styling */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
        }

        .modal-content h2 {
            margin-bottom: 20px;
        }

        .modal-content input, .modal-content select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .modal-content button {
            padding: 10px 20px;
            border: none;
            background: #28a745;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .modal-content .close-btn {
            background: #dc3545;
        }

        /* Employee checkbox layout */
        .checkbox-group {
            max-height: 300px;
            overflow-y: auto;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-group label {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .checkbox-group input {
            margin-right: 10px;
        }

        /* Style for select all checkbox */
        #selectAll {
            margin-top: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<!-- header -->
<?php include_once("./includes/header.php"); ?>

<!-- sidebar -->
<?php include_once("./includes/sidebar.php"); ?>

<main class="content">
    <div class="welcome-box2">
        PAYROLL LIST
    </div>

    <div class="controls">
        <div class="search-container">
            <form method="GET" action="payrollList.php">
                <label for="month">Month:</label>
                <select name="month" id="month">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?= $m ?>" <?= $month == $m ? 'selected' : '' ?>>
                            <?= date('F', mktime(0, 0, 0, $m, 10)) ?>
                        </option>
                    <?php endfor; ?>
                </select>

                <label for="year">Year:</label>
                <input type="number" name="year" id="year" value="<?= $year ?>" required>

                <button type="submit">Filter</button>
            </form>
        </div>
    </div>

    <table class="payroll-table">
    <thead>
        <tr>
            <th>Payroll ID</th>
            <th>Employee Name</th>
            <th>Net Pay</th>
            <th>Month</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['employee_name']) ?></td>
                    <td>₱<?= number_format($row['net_pay'], 2) ?></td>
                    <td><?= date('F', mktime(0, 0, 0, $month, 10)) . ' ' . $year ?></td>
                    <td class="action-buttons">
                        <a href="?delete_id=<?= $row['id'] ?>" class="delete" onclick="return confirm('Are you sure you want to delete this record?')"><img src="./assets/images/delete.png" style="height: 20px; width: 25px; padding-top: 3px"></a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No payroll records found for the selected date range.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

</main>
<?php include_once("./modal/logout-modal.php"); ?>

<!-- footer -->
<?php include_once("./includes/footer.php"); ?>

</body>
</html>

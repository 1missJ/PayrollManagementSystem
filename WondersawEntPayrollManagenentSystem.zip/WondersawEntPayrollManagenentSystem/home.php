<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="./assets/css/home.css">
</head>
<body>

    <!-- header -->
    <?php include_once("./includes/header.php"); ?>

    <!-- sidebar -->
    <?php include_once("./includes/sidebar.php"); ?>

    <!-- Add Image Here -->
    <img src="./assets/images/logo-admin.png" alt="Background Image" class="background-image">

    <main class="content">
        <!-- Your content here -->
    </main>

    <!-- footer -->
    <?php include_once("./includes/footer.php"); ?>
    <!-- modal -->
    <?php include_once("./modal/logout-modal.php"); ?>

</body>
</html>

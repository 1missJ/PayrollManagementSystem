<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php"); 
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Branch List</title>
    <style>
        /* General Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            overflow: hidden;
            background-color: #ffe4c4;
        }

        .header {
            width: 100%;
            height: 90px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff3e0;
            border-top: 1px solid #ccc;
            padding: 0 20px;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            z-index: 1;
        }

        .header-left {
            display: flex;
            align-items: center;
        }

        .logo-img {
            height: 50px;
        }

        .header-right {
            display: flex;
            align-items: center;
            font-weight: bold;
        }

        .admin-text {
            margin-right: 10px;
            font-size: 1.1rem;
        }

        .logout-icon {
            font-size: 1.5rem;
            color: black;
            text-decoration: none;
        }

        .sidebar {
            width: 250px;
            padding-top: 110px;
            background-color: #ffa07a;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            width: 100%;
        }

        .sidebar ul li a {
            display: flex;
            align-items: center;
            padding: 15px;
            color: black;
            font-weight: bold;
            text-decoration: none;
            transition: background-color 0.2s ease;
        }

        .sidebar ul li.active a {
            background-color: #ff8c66;
        }

        .icon {
            margin-right: 10px;
        }

        .content {
            margin-left: 250px;
            padding-top: 100px;
            padding: 20px;
            width: calc(100% - 250px);
            height: calc(100vh - 60px);
            overflow-y: auto;
            background-color: #ffe4c4;
        }

        .Branch-box {
            background-color: #ffffff;
            padding: 20px;
            border: 2px solid #f4a460;
            margin-top: 100px;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .Branch-form {
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #f4a460;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            margin-top: 20px;
        }

        .Branch-form input, .Branch-form select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
        }

        .form-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .btn-save {
            background-color: #ffa07a;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-cancel {
            background-color: #ccc;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .save-btn {
            background-color: #ffa07a;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .cancel-btn {
            background-color: #ccc;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .Branch-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .Branch-table th, .Branch-table td {
            border: 1px solid #ccc;
            background-color: white;
            padding: 10px;
            text-align: center;
        }

        .Branch-table th {
            background-color: white;
            color: black;
            font-weight: bold;
        }
        .logout-icon {
            font-size: 1.5rem;
            color: black;
            text-decoration: none;
        }
        .logout-overlay {
            display: none;
            background-color: rgba(0, 0, 0, 0.5);
            margin-top: 60px;
           margin-left: 1100px;
            position: fixed;
            top: 0;
            left: 0;
            justify-content: center;
            align-items: center;
            z-index: 2;
        }
        .logout-content {
            background-color: #fff;
            padding: 20px;
            width: 400px;
            border-radius: 5px;
            text-align: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        
        .controls {
            display: flex;
            align-items: center;
            justify-content:space-evenly;
            margin-top: 50px;
        }

        .search-container {
            display: flex;
            align-items: center;
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 5px 10px;
            background-color: #ffffff;
        }

        .search-bar {
            border: none;
            outline: none;
            width: 200px;
            font-size: 1rem;
            background-color: transparent;
        }

        .search-btn {
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            color: #666;
        }
        .add-Employee-btn {
            padding: 8px 12px;
            font-size: 1rem;
            background-color: #ffa07a;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .confirm-btn {
            background-color: #ffa07a;
            color: white;
        }

        .cancel-btn {
            background-color: #ccc;
            color: black;
        }
        .confirm-btn, .cancel-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .modal-body,
        .modal-footer {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
    }

    /* Center the select dropdown */
    .form-group select {
        width: 100%;
        max-width: 300px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        margin-bottom: 20px;
    }
        .logout-header {
            font-size: 1.5rem;
            margin-bottom: 10px;
            font-weight: bold;
        }
              /* Modal Styling */
              .modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
    z-index: 2;
}

/* Modal Content */
.modal-content {
    width: 50%; /* Adjust the width of the modal */
    max-width: 500px;
    margin: 0 auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
}

/* Modal Body */
.modal-body {
    display: flex;
    justify-content: space-between;
    gap: 20px; /* Space between the left and right columns */
}

/* Left Column (First Name, Last Name, etc.) */
.left-column {
    flex: 1;
}

/* Right Column (Middle Name, Address, etc.) */
.right-column {
    flex: 1;
}

        /* Form Group (for each input field) */
.form-group {
    display: flex;
    align-items: center;
    gap: 10px; /* Space between label and input */
    margin-bottom: 15px; /* Space between form groups */
}

/* Labels */
.modal-body label {
    font-weight: bold;
    font-size: 14px;
    color: #333;
    width: 150px; /* Fixed width for labels to ensure they align properly */
}

/* Input Fields */
.modal-body input {
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 100%; /* Inputs take the remaining space */
    box-sizing: border-box;
}

/* Date Inputs */
.modal-body input[type="date"] {
    width: 100%;
    padding: 10px;
}

/* Modal Footer */
.modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
}

.modal-footer .save-btn,
.modal-footer .cancel-btn {
    padding: 10px 20px;
    font-size: 14px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.modal-footer .save-btn {
    background-color: #4CAF50;
    color: white;
}
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #fff3e0;
            font-size: 0.9rem;
            color: #333;
            border-top: 1px solid #ccc;
            z-index: 1;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-left">
            <img src="logo.png" alt="Logo" class="logo-img" style="height: 10vh; margin-right: -505px;">
        </div>
        <div class="header-right">
            <span class="admin-text">ADMINISTRATOR</span>
            <a href="#" class="logout-icon" onclick="showLogoutConfirmation(event)">
                <img src="logout.png" alt="logout" style="height: 25px;">
            </a>
        </div>
    </header>

    <div class="sidebar">
        <ul>
            <li><a href="home.php"><i class="icon">🏠</i> Home</a></li>
            <li><a href="payrollList.php"><i class="icon">💸</i> Payroll</a></li>
            <li><a href="employee.php"><i class="icon">👥</i> Employees</a></li>
            <li class="active"><a href="branch.php"><i class="icon">🏢</i> Branch</a></li>
            <li><a href="deductionList.php"><i class="icon">➖</i> Deduction</a></li>
            <li><a href="salarySlip.php"><i class="icon">📄</i> Salary Slip</a></li>
            <li><a href="user.php"><i class="icon">👤</i> User</a></li>
        </ul>
    </div>

    <main class="content">
        <div class="Branch-box">
            Branch
        </div>
        <div class="Branch-form">
            <h3 style="text-align: center; font-weight: bold;">Add Branch</h3>
            <div style="border-top: 2px solid black; margin: 10px 0;"></div>
            <label for="department-manager">Department Manager</label>
            <input type="text" id="department-manager" required>
            <label for="department-address">Department Address</label>
            <input type="text" id="department-address" required>
            <div style="border-top: 2px solid black; margin: 20px 0;"></div>
            <div class="form-buttons">
                <button class="cancel-btn" onclick="alert('Canceled')">CANCEL</button>
                <button class="save-btn" onclick="alert('Saved')">SAVE</button>
            </div>
        </div>

        <div class="controls">
            <div class="search-container">
                <input type="text" placeholder="Search" class="search-bar">
                <button class="search-btn">🔍</button>
            </div>
            <button class="add-Employee-btn" onclick="showModal()">+ Add Employee</button>
        </div>

        <table class="Branch-table">
            <thead>
                <tr>
                    <th>Branch Information</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>ABSCBN</td>
                    <td>
                       <a href="view_branch_employee.php"><button class="view"><img src="eye.png" alt="eye"></button></a> 
                        <a href="" class="delete"><img src="delete.png" alt="delete" style="height: 20px; width: 25px;"></a>
                    </td>
                </tr>
            </tbody>
        </table>
    </main>

    <div id="newEmployeeModal" class="modal">
    <div class="modal-content">
        <form method="POST" action="view_branch_employee.php">
            <div class="modal-header">
                <h3 style="text-align:center;">SELECT BRANCH</h3><br>
            </div>
            <div class="modal-body">
                    <div class="form-group">
                        <select id="branch" name="branch" required>
                            <option value="" disabled selected>Select Branch</option>
                            <option value="ABS-CBN">ABS-CBN</option>
                            <option value="WONDERSAW">WONDERSAW</option>
                            <option value="GMA">GMA</option>
                        </select>
                    </div>
                </div>
                <center>
                <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                <button type="submit" name="save_employee" class="btn-save">Yes</button>
                </center>
            </div>
            </div>
        </form>
    </div>
</div>

    <footer class="footer">
            © 2024 Payroll Management System. All rights reserved.
    </footer>
    
    <div class="logout-overlay" id="logoutOverlay">
        <div class="logout-content">
            <div class="logout-header" style="padding: 20px;">Confirmation</div>
            <div style="border-top: 2px solid black; margin: 10px 0;"></div>
            <p style="padding: 30px;">Are you sure you want to log out?</p>
            <div style="border-top: 2px solid black; margin: 10px 0;"></div>
            <div class="logout-footer">
                <button class="cancel-btn" onclick="closeLogoutConfirmation()">No</button>
                <a href="logout.php?logout=confirm"><button class="confirm-btn">Yes</button></a>
            </div>
        </div>
    </div>

    <script>
        function showModal() {
            document.getElementById('newEmployeeModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('newEmployeeModal').style.display = 'none';
        }

        function closeViewModal() {
    window.location.href = 'branch.php'; // Redirect to main branch page
}

        function closeEditModal() {
            window.location.href = '#'; // Redirect to main # page
        }
        function showLogoutConfirmation(event) {
            event.preventDefault();
            document.getElementById("logoutOverlay").style.display = "flex";
        }

        function closeLogoutConfirmation() {
            document.getElementById("logoutOverlay").style.display = "none";
        }
        function showLogoutModal() {
            document.getElementById('logoutOverlay').style.display = 'flex';
        }
        function closeLogoutConfirmation() {
            document.getElementById('logoutOverlay').style.display = 'none';
        }
    </script>
</body>
</html>
